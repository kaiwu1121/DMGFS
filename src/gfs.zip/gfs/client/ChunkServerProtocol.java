//package gfs.server.protocol;

//import gfs.protocol.Chunk;
import java.rmi.Remote;
import java.util.Map;


public interface ChunkServerProtocol extends Remote {

   
    public int saveChunk(Chunk chunk, byte[] stream, String server) throws Exception;

    public int updateChunk(Chunk chunk, byte[] stream, String socket) throws Exception;
    
    public int deleteChunk(Chunk chunk) throws Exception;

    public String getUpdate(Chunk chunk) throws Exception;

    
    public byte[] getChunk(Chunk chunk) throws Exception;

   
    public Map<Long, String> hbCheck() throws Exception;

   
    public void backupChunk(Chunk chunk, String ip) throws Exception;
}
